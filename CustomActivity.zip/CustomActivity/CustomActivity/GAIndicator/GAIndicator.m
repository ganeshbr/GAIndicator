//
//  GAIndicator.m
//  CustomActivity
//
//  Created by rikazzak@gamil.com on 7/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GAIndicator.h"

@implementation GAIndicator

UIView *animatingView=nil;
CGFloat finalX;
NSInteger velocity=1;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        
    }
    return self;
}

-(void)stopAnimating
{
     velocity=1;
    [animatingView removeFromSuperview];
    [self removeFromSuperview];
    animatingView=nil;
}

-(void)startAnimating
{
    self.layer.cornerRadius=CORNER_RADIUS;
    self.backgroundColor=BGCOLOR;
    animatingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width/5, self.frame.size.height)];
    animatingView.layer.cornerRadius=CORNER_RADIUS;
    [self addSubview:animatingView];
    animatingView.backgroundColor = [UIColor colorWithRed:INNERRED/255.0f green:INNERGREEN/255.0f blue:INNERBLUE/255.0f alpha:INNERALPHA];
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = animatingView.bounds;
    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6] CGColor], (id)[[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.6] CGColor], nil];
    gradient.cornerRadius=animatingView.layer.cornerRadius;
    [animatingView.layer insertSublayer:gradient atIndex:0];
    
    CAGradientLayer *superGradient = [CAGradientLayer layer];
    superGradient.frame = self.bounds;
    superGradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.6] CGColor], (id)[[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.6] CGColor], nil];
    superGradient.cornerRadius=self.layer.cornerRadius;
    [self.layer insertSublayer:superGradient atIndex:0];
    
    animatingView.layer.shadowColor = [[UIColor blackColor] CGColor];
    animatingView.layer.shadowOffset = CGSizeMake(2.0, 2.0);
    animatingView.layer.shadowOpacity = 0.25;
    finalX= self.frame.size.width-(animatingView.frame.size.width/2);
    [NSTimer scheduledTimerWithTimeInterval:0.006 target:self selector:@selector(animate:) userInfo:nil repeats:YES];
}

-(void)animate:(NSTimer *)timer
{
    CGFloat centerX = animatingView.center.x;
    centerX+=velocity;
    
    if(centerX>finalX)
        velocity=-velocity;
    else if(centerX<(animatingView.frame.size.width)/2) 
        velocity=-velocity;
        
    animatingView.center=CGPointMake(centerX, animatingView.center.y);
}

@end
