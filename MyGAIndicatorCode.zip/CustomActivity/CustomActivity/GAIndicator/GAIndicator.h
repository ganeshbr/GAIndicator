//
//  GAIndicator.h
//  CustomActivity
//
//  Created by rikazzak@gamil.com on 7/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#define CORNER_RADIUS 10.0
#define BGCOLOR [UIColor whiteColor]
#define INNERRED 20.0f
#define INNERGREEN 200.0f
#define INNERBLUE 20.0f
#define INNERALPHA 1.0
@interface GAIndicator : UIView
-(void)startAnimating;
@end
